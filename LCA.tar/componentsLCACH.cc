#include <string>
#include "componentsLCACH.h"
#include "componentsLCA.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsCH::WSN_ComponentsCH() {}

WSN_ComponentsCH::WSN_ComponentsCH(Agent *agent) {
	compLib = new WSN_ComponentsLib();
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCH::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

template <class K, class V> void WSN_ComponentsCH::SelectCH(std::map<K, V> setNeighbors) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);

	int min;

	if (agent->getCompSensor()->lastMsg == CH_ANNOUNCE && agent->getCompSensor()->role == UNKNOWN) {
		agent->getCompSensor()->role = CM;
		return;
	}

	if ( setNeighbors.size() > 0 )
		min = compLib->MIN(setNeighbors).at("ID");
	else 
		min = agent->getCompSensor()->getSensorId();

	if ( (agent->getCompSensor()->getSensorId() <= min) || agent->getCompSensor()->lastMsg != CH_ANNOUNCE )  {
		printf("SELECT_CH - sou CH %d (%f)\n", agent->getCompSensor()->getSensorId(), CURRENT_TIME);
		param.setId(agent->getCompSensor()->getSensorId());
		sp.id = param.getId();
		agent->getCompSensor()->role = CH;
		
		param.setMsgId(CH_ANNOUNCE);
		newp.size = 1;
		newp.msgParam[0] = sp;
		param.getHdrWsnComp()->msgParams = newp;
		agent->SendPkt(CH_ANNOUNCE, &param);
	} else {
		agent->getCompSensor()->role = CM;
	}
}

template void WSN_ComponentsCH::SelectCH(std::map<string, int>);
