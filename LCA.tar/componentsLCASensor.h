#ifndef _WSN_COMPONENTS_LCA_SENSOR_
#define _WSN_COMPONENTS_LCA_SENSOR_

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <sstream>
#include <math.h>
#include <random.h>
#include "packet.h"
#include "hdr_components.h"
#include <mobilenode.h>
#include "agent.h"

using namespace std;

class WSN_ComponentsSensor;

enum SensorRole {
	UNKNOWN,
	CH,
	CM
};

class WSN_ComponentsSensor {

public: 
	void setAgent(Agent *);
	void setSensorId(int);
	std::map<string, int> GetCHElectionParams();
	std::map<string, int> GetJoinParams();

	void init(int);

	SensorRole role;

	void AddNeighbor(SensorDataParams);
	void getNeighbors();
	void AddProbe(SensorDataParams);
	void DiscoverNeighbor();
	void ACKDiscoverNeighbor();
	void ProcessMessage(WSN_Components_Message *);
	void ManageRoundCommand(RoundCommand);
	void AddCandidateCH(SensorDataParams);
	void AddCandidateMember(SensorDataParams);
	void CommandPrintCandidateCH();
	void CommandPrintCandidateMembers();
	void CommandPrintCHs();
	void resendstartflooding(WSN_Components_Message*);

	bool contains(int addr, vector<int> v){
		for(vector<int>::iterator i = v.begin(); i != v.end(); i++){
			if((*i) == addr){     
				return true;
			}
		}
		return false; 
	}

	bool contains(int addr, vector<SensorDataParams> v){
		for(vector<SensorDataParams>::iterator i = v.begin(); i != v.end(); i++){
			if((*i).id == addr){     
				return true;
			}
		}
		return false; 
	}

	bool isfloodingsent(int uid){
		for (list<int>::iterator i = lstpktflooding.begin(); i != lstpktflooding.end(); i++){
			if ((*i) == uid){
				return true;
			}
		}
		return false;
	}

	void resetfloodingsent() { lstpktflooding.clear(); }

	void addfloodingsent(int uid){
		lstpktflooding.push_front(uid);
	}
	
	vector<SensorDataParams> getVecCandidateCH() { return vecCandidateCH; }
	vector<SensorDataParams> getVecCandidateMembers() { return vecCandidateMembers; }
	vector<SensorDataParams> getVecRecvProbeMsg() { return vecRecvProbeMsg; }
	vector<SensorDataParams> getVecNeighbors() { return vecNeighbors;	}
	list<int> lstpktflooding;

	int getSensorId() {
		return sensorId;
	}

	// sensor coordinators
	int getX()  { return coordX; }
	int getY() { return coordY; }
	int getZ()  { return coordZ; }
	void setX(int latitude)  { coordX = latitude; }
	void setY(int longitude) { coordY = longitude; }
	void setZ(int altitude)  { coordZ = altitude; }
	void setCoords(int lat, int lon, int alt) {
		coordX = lat;
		coordY = lon;
		coordZ = alt;
	}

	int getNumSensors() { return numSensors; }
	MsgID lastMsg;

private:
	Agent *agent_;
	int sensorId;

	// Neighbors
	vector<SensorDataParams> vecNeighbors;
	vector<int> vecCHNeighbors;

	//CandidateCH
	vector<SensorDataParams> vecCandidateCH;
	vector<SensorDataParams> vecCandidateMembers;
	vector<SensorDataParams> vecRecvProbeMsg;

	int coordX;
	int coordY;
	int coordZ;

	int numSensors;
};

#endif
