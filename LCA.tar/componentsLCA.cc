#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include "componentsLCA.h"
#include "componentsLib.h"

int hdr_wsn_components::offset_;

#define CURRENT_TIME Scheduler::instance().clock() 

using namespace std;

static class WSN_ComponentsAgentClass : public TclClass {
public:
	WSN_ComponentsAgentClass() : TclClass("Agent/WSN_COMPONENTS") {}
	TclObject* create(int, const char*const* argv) {
		return (new WSN_ComponentsAgent());
	}
} class_WSN_COMPONENTS;

WSN_ComponentsAgent::WSN_ComponentsAgent() : Agent(PT_WSN_COMPONENTS), libTimer(this) { 
	bind("packetSize_", &size_);
	myaddr = 0;
	node = NULL;

	compSensor = new WSN_ComponentsSensor();
	compCH = new WSN_ComponentsCH();
	compCM = new WSN_ComponentsCM();
}

int WSN_ComponentsAgent::command(int argc, const char*const* argv) {
	if ( argc > 1 ) {
		const char* command = argv[1];

		if (strcasecmp(command, "START_WSN_COMPONENTS") == 0) {
			return TCL_OK;
		} else if (strcmp(command, "DISCOVER_NEIGHBORS") == 0) {
			CommandDiscoverNeighbors();			
			return TCL_OK;
		} else if (strcmp(command, "SELECT_CH") == 0) {
			CommandSelectCH();			
			return TCL_OK;
		} else if (strcmp(argv[1], "INIT") == 0) {
			CommandInit(argv);
			return TCL_OK;
		} else if (strcmp(command, "PRINT") == 0) {
			const char* commandPrint = argv[2];
			CommandPrint(commandPrint);
			return TCL_OK;
		} else if (strcasecmp (argv[1], "tracetarget") == 0) {
			TclObject *obj;
			if ((obj = TclObject::lookup (argv[2])) == 0) {
				fprintf (stderr, "%s: %s lookup of %s failed\n", 
								__FILE__, argv[1], argv[2]);
				return TCL_ERROR;
			}
			tracetarget = (Trace *) obj;
			return TCL_OK;
		} else if (strcasecmp(argv[1], "port-dmux") == 0) {
			return TCL_OK;
		} else if (strcasecmp(argv[1], "node") == 0) {
			node = (MobileNode*) TclObject::lookup(argv[2]);
			return TCL_OK;
		} else if (strcasecmp(argv[1], "addr") == 0) {
			myaddr = Address::instance().str2addr(argv[2]);
			compSensor->setSensorId(myaddr);
			compSensor->setAgent(this);
			compCH->setAgent(this);
			compCM->setAgent(this);
			return TCL_OK;
		} else if(strcasecmp(argv[1],"POSITION")==0) {
			if(compSensor->getSensorId() == 0) return TCL_OK;
		 	CommandPosition(argv);

			return TCL_OK;
		}
	}
	return (Agent::command(argc, argv));
}

void WSN_ComponentsAgent::CommandPrint(const char* p) { 
	if (strcmp(p, "GET_NEIGHBORS") == 0) 
		compSensor->getNeighbors();
	else if (strcmp(p, "CANDIDATECH") == 0)
		compSensor->CommandPrintCandidateCH();
	else if (strcmp(p, "MEMBERS") == 0)
		compSensor->CommandPrintCandidateMembers();
	else if (strcmp(p, "CHs") == 0)
		compSensor->CommandPrintCHs();
}

void WSN_ComponentsAgent::CommandInit(const char*const* argv) {
	compSensor->init(atoi(argv[2]));
}

void WSN_ComponentsAgent::CommandPosition(const char*const* argv) {
	compSensor->setCoords(atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
}

void WSN_ComponentsAgent::SendPkt(MsgID msgID, WSN_Components_Message* param) {
	param->setPrevHop(compSensor->getSensorId());
	param->setNextHop(IP_BROADCAST);
	param->setAddressType(NS_AF_INET);
	param->setDirection(hdr_cmn::DOWN);

	double r = ((double) rand() / (RAND_MAX));
	Scheduler::instance().schedule(target_, param->getPkt(), (r/10));
}

void WSN_ComponentsAgent::recv(Packet* pkt, Handler *) {
	assert(initialized());
	assert(pkt);

	WSN_Components_Message param = pkt;
	compSensor->ProcessMessage(&param);
}

void WSN_ComponentsAgent::CommandDiscoverNeighbors() {
	compSensor->setSensorId(myaddr);
	InitTimer();
	roundCmd = DISCOVER_NEIGHBORS;
}

void WSN_ComponentsAgent::CommandSelectCH() {
	compSensor->setSensorId(myaddr);
	InitTimer();
	roundCmd = SELECT_CH;
}

void WSN_ComponentsAgent::InitTimer() {
	libTimer.resched(CURRENT_TIME + compSensor->getSensorId());
}

void WSN_ComponentsAgent::ResetTimer() {
	libTimer.resched(CURRENT_TIME + compSensor->getNumSensors());
}

void WSN_ComponentsAgent::TimerHandle(RoundCommand roundCmd) {
	switch (roundCmd) {
		case DISCOVER_NEIGHBORS:
		{
			compSensor->ManageRoundCommand(roundCmd);
			ResetTimer();
		}
			break;
		case ACK_DISCOVER_NEIGHBORS:
		{
			compSensor->ManageRoundCommand(roundCmd);
		}
			break;
		case SELECT_CH:
		{
			std::map<string, int> mapUID = compSensor->GetCHElectionParams();
			compCH->SelectCH(mapUID);

			roundCmd = JOIN_CLUSTER;
			ResetTimer();
		}
			break;
		case JOIN_CLUSTER:
		{
			compSensor->resetfloodingsent();
			vector<SensorDataParams> vecCandidateCH = getCompSensor()->getVecCandidateCH();

			std::map<string, int> mapCandidateCH = compSensor->GetJoinParams();
			if (vecCandidateCH.size() > 0) {
				printf("TimerHandle Join_Cluster %f \n", CURRENT_TIME);
				compCM->JoinCluster(mapCandidateCH);
			}
		}
			break;
	}
}

void WSN_Timer::expire(Event* /*e*/) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(a_);

	if (agent->roundCmd == DISCOVER_NEIGHBORS) {
		agent->TimerHandle(DISCOVER_NEIGHBORS);
		agent->roundCmd = ACK_DISCOVER_NEIGHBORS;
	} else if (agent->roundCmd == ACK_DISCOVER_NEIGHBORS) {
		agent->TimerHandle(ACK_DISCOVER_NEIGHBORS);
	} else if (agent->roundCmd == SELECT_CH) {
		agent->TimerHandle(SELECT_CH);
		agent->roundCmd = JOIN_CLUSTER;
	} else if (agent->roundCmd == JOIN_CLUSTER) {
		agent->TimerHandle(JOIN_CLUSTER);
		agent->roundCmd = FINISH;
	}
}

