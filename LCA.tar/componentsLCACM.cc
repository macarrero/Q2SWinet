#include <string>
#include "componentsLCA.h"
#include "componentsLCACM.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsCM::WSN_ComponentsCM() {}

WSN_ComponentsCM::WSN_ComponentsCM(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCM::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
	compLib = new WSN_ComponentsLib();
}

template <class K, class V> void WSN_ComponentsCM::JoinCluster(std::map<K, V> setCandidateCH) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);
	MsgParam newp;
	SensorDataParams sp;

	printf("No %d Role %d JoinCluster (%f)\n", agent->getCompSensor()->getSensorId(), agent->getCompSensor()->role, CURRENT_TIME);
	if ( agent->getCompSensor()->role == CM ) {
		int i = 0;
		int min = compLib->MIN(setCandidateCH).at("ID");
		sp.id = min;

		printf("No %d Role %d minCandidateCH %d (%f)\n", agent->getCompSensor()->getSensorId(), agent->getCompSensor()->role, min, CURRENT_TIME);

		param.setId(agent->getCompSensor()->getSensorId());
		newp.size = 1;
		newp.msgParam[0] = sp;
		param.setMsgId(ACK_CH_ANNOUNCE);
		param.getHdrWsnComp()->msgParams = newp;
		agent->SendPkt(ACK_CH_ANNOUNCE, &param);
	}
}

template void WSN_ComponentsCM::JoinCluster(std::map<string, int>);
