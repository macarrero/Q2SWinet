#ifndef _WSN_COMPONENTS_LCA_
#define _WSN_COMPONENTS_LCA_

#include <mobilenode.h>
#include "componentsLCACH.h"
#include "componentsLCACM.h"
#include "componentsLCASensor.h"
#include "componentsLib.h"
#include "agent.h"
#include "packet.h"
#include "address.h"
#include "tclcl.h"
#include "ip.h"

using namespace std;

class WSN_ComponentsAgent;

typedef struct{
	int pktid;
} pktflooding;

class WSN_ComponentsAgent: public Agent {
	friend class RtxComponentTimer;

	friend class ClusterDefinitionTimer;
	int numSensors_;
	
public:
	WSN_ComponentsAgent();
	SensorRole role;
	int** neighboringMatrix;
	void createneighboringMatrix(int, int);
	void SendPkt(MsgID, WSN_Components_Message *);
	void AddFloodingSent(int);
	void AddTwoHopNeighbor(int);
	bool IsFloodingSent(int);
	void CommandInit(const char*const* argv);
	void CommandPosition(const char*const* argv);
	void CommandDiscoverNeighbors();
	void CommandSelectCH();
	void CommandGetNeighbors();
	void CommandPrint(const char*);
	void CommandPing();
	void ResetTimer();
	void InitTimer();
	void TimerHandle(RoundCommand);
	inline Packet* getNewPkt() { return allocpkt(); }
	void setLastMsg(MsgID);
	MsgID getLastMsg();
	virtual void recv (Packet *, Handler *);
	virtual int command(int, const char*const*);
	RoundCommand roundCmd;

	WSN_ComponentsSensor* getCompSensor() { return compSensor; }
	WSN_Timer getLibTimer() { return libTimer; }


protected:
	MobileNode *node;
	Trace *tracetarget;
	int myaddr;
	MsgID lastMsg;
	list<pktflooding> lstPktFlooding;
	vector<int> vecNeighbors;
	list<int> lstTwoHopNeighbors;
	WSN_Timer libTimer;

private:
	WSN_ComponentsSensor* compSensor;
	WSN_ComponentsCH *compCH;
	WSN_ComponentsCM *compCM;
	WSN_ComponentsLib compLib;

	vector<SensorDataParams> vecSensorDataParams;

};

#endif
