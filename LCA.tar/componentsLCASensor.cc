#include "componentsLCASensor.h"
#include "componentsLCA.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

void WSN_ComponentsSensor::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsSensor::setSensorId(int id) {
	sensorId = id;
}

std::map<string, int> WSN_ComponentsSensor::GetCHElectionParams() {
	std::map<string, int> mapUID;
	std::string id=("ID");

	if (lastMsg == CH_ANNOUNCE) return mapUID;

	if (vecCHNeighbors.size() >0) {
		for ( int j = 0; j < vecCHNeighbors.size(); j++ ) {
			int uid = vecCHNeighbors.at(j);
				string newId = static_cast<std::ostringstream*>( &(ostringstream() << uid) )->str();
				mapUID.insert(std::pair<string, int> (id.append(id), uid));
		}

	}

	return mapUID;
}

std::map<string, int> WSN_ComponentsSensor::GetJoinParams() {
	vector<SensorDataParams> vecCandidateCH = getVecCandidateCH();
	std::map<string, int> mapCandidateCH;

	if (vecCandidateCH.size() > 0) {
		SensorDataParams sdp = vecCandidateCH.at(0);
		std::string id=("ID");
		mapCandidateCH.insert(std::pair<string, int> (id.append(id), sdp.id));

		for ( int j = 1; j < vecCandidateCH.size(); j++ ) {
			sdp = vecCandidateCH.at(j);
			string newId = static_cast<std::ostringstream*>( &(ostringstream() << sdp.id) )->str();
			mapCandidateCH.insert(std::pair<string, int> (id.append(id), sdp.id));
		}
		return mapCandidateCH;
	}
}

void WSN_ComponentsSensor::init(int numSensors) {
	this->numSensors=numSensors;
}

void WSN_ComponentsSensor::AddNeighbor(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecNeighbors)) {
		vecNeighbors.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::AddProbe(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecRecvProbeMsg))
		vecRecvProbeMsg.push_back(sensorDataParams);
}

void WSN_ComponentsSensor::AddCandidateCH(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecCandidateCH)) {
		vecCandidateCH.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::AddCandidateMember(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecCandidateMembers)) {
		vecCandidateMembers.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::ManageRoundCommand(RoundCommand roundCmd) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);
	param.setId(getSensorId());

	switch (roundCmd) {
		case DISCOVER_NEIGHBORS:
		{
			param.setMsgId(SENSOR_ID);

			newp.size = 1;
			sp.id = param.getId(); 
			sp.coordX = getX();
			sp.coordY = getY();
			sp.coordZ = getZ();

			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			agent->SendPkt(SENSOR_ID, &param);
		}
		break;
		case ACK_DISCOVER_NEIGHBORS:
		{
			param.setMsgId(ACK_SENSOR_ID);
			newp.size = getVecRecvProbeMsg().size();

			int i = 0;

			for (vector<SensorDataParams>::iterator x=vecRecvProbeMsg.begin(); x!= vecRecvProbeMsg.end(); x++) {
				sp.id = (*x).id;
				sp.coordX = (*x).coordX;
				sp.coordY = (*x).coordY;
				sp.coordZ = (*x).coordZ;

				newp.msgParam[i] = sp;
				i++;
			}
			param.getHdrWsnComp()->msgParams = newp;
			agent->SendPkt(ACK_SENSOR_ID, &param); 
		}
		break;
	}
}

void WSN_ComponentsSensor::ProcessMessage(WSN_Components_Message* param) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	double Xr, Yr, Zr;
	param->getPkt()->txinfo_.getNode()->getLoc(&Xr, &Yr, &Zr);
	SensorDataParams sp;

	switch(param->getMsgId())
	{
		case (SENSOR_ID):
		{
			int id = param->getHdrWsnComp()->msgParams.msgParam[0].id;

			sp.id = param->getHdrWsnComp()->msgParams.msgParam[0].id;
			sp.coordX = param->getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			sp.coordY = param->getHdrWsnComp()->msgParams.msgParam[0].coordY; 

			AddProbe(sp);
		}
		break;
		case (ACK_SENSOR_ID):
		{
			int size = param->getHdrWsnComp()->msgParams.size;
			for (int i=0; i < size; i++) {
				param->getPkt()->txinfo_.getNode()->getLoc(&Xr, &Yr, &Zr);
				if (getSensorId() == param->getHdrWsnComp()->msgParams.msgParam[i].id) { 
					sp.id = param->getHdrCmn()->prev_hop_; 
					sp.coordX = Xr; 
					sp.coordY = Yr;

					AddNeighbor(sp);
					if (!contains(sp.id, vecCHNeighbors))
						vecCHNeighbors.push_back(sp.id);
				}
			}
		}
		break;
		case (CH_ANNOUNCE):
		{
			int size = param->getHdrWsnComp()->msgParams.size;
			lastMsg=CH_ANNOUNCE;
			sp.id = param->getHdrWsnComp()->msgParams.msgParam[0].id;
			AddCandidateCH(sp);

			if (isfloodingsent(param->getHdrWsnComp()->uid)) {
				Packet::free( param->getPkt());
				break;
			}

			if (contains(sp.id, vecCHNeighbors) && role != CH) {
				addfloodingsent(param->getHdrWsnComp()->uid);
				resendstartflooding(param);
			}

		}
		break;
		case (ACK_CH_ANNOUNCE):
		{
			int size = param->getHdrWsnComp()->msgParams.size;
			if ( role == CH ) {
				if (getSensorId() == param->getHdrWsnComp()->msgParams.msgParam[0].id) {
					sp.id = param->getHdrWsnComp()->uid; 
					AddCandidateMember(sp);
				}
			}

			if (isfloodingsent(param->getHdrWsnComp()->uid)) {
				Packet::free( param->getPkt());
				break;
			}

			if (  contains(param->getHdrWsnComp()->msgParams.msgParam[0].id, vecCHNeighbors) ) {
				addfloodingsent(param->getHdrWsnComp()->uid);
				resendstartflooding(param);
			}
	
		}
		break;
	}
} 

void WSN_ComponentsSensor::resendstartflooding(WSN_Components_Message* param){
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;

	param->setId(param->getHdrWsnComp()->uid);
	param->getHdrCmn()->uid_ = 1;
	param->setNextHop(IP_BROADCAST);
	param->setAddressType(NS_AF_INET);
	param->setDirection(hdr_cmn::DOWN);		// packet direction
	param->setPrevHop(getSensorId());
	param->setHop();

	sp.id = param->getId();
	newp.size = 1;
	newp.msgParam[0] = sp;

	agent->SendPkt(param->getMsgId(), param);
	addfloodingsent(param->getHdrWsnComp()->uid);
}

void WSN_ComponentsSensor::getNeighbors() {
	printf("\nVecNeig de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<int>::iterator i = vecCHNeighbors.begin(); i != vecCHNeighbors.end(); i++) {
		printf("%d ",(*i));
	}

}

void WSN_ComponentsSensor::CommandPrintCandidateCH() {
	printf("\nCandidateCH de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecCandidateCH.begin(); i != vecCandidateCH.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintCandidateMembers() {
	printf("\nCandidateMembers de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecCandidateMembers.begin(); i != vecCandidateMembers.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintCHs() {
	if (this->role == CH)
		printf("\nCH %d (%f): ", getSensorId(), CURRENT_TIME);
}
