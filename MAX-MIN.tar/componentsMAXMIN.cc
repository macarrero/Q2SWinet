#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include "componentsMAXMIN.h"
#include "componentsLib.h"

int hdr_wsn_components::offset_;

#define CURRENT_TIME Scheduler::instance().clock() 

using namespace std;

static class WSN_ComponentsAgentClass : public TclClass {
public:
	WSN_ComponentsAgentClass() : TclClass("Agent/WSN_COMPONENTS") {}
	TclObject* create(int, const char*const* argv) {
		return (new WSN_ComponentsAgent());
	}
} class_WSN_COMPONENTS;

WSN_ComponentsAgent::WSN_ComponentsAgent() : Agent(PT_WSN_COMPONENTS), libTimer(this) { 
	bind("packetSize_", &size_);
	myaddr = 0;
	node = NULL;

	compSensor = new WSN_ComponentsSensor();
	compCH = new WSN_ComponentsCH();
	compCM = new WSN_ComponentsCM();
}

int WSN_ComponentsAgent::command(int argc, const char*const* argv) {
	if ( argc > 1 ) {
		const char* command = argv[1];

		if (strcasecmp(command, "START_WSN_COMPONENTS") == 0) {
			return TCL_OK;
		} else if (strcmp(command, "DISCOVER_NEIGHBORS") == 0) {
			CommandDiscoverNeighbors();			
			return TCL_OK;
		} else if (strcmp(command, "FLOOD_MAX") == 0) {
			CommandFloodMax();			
			return TCL_OK;
		} else if (strcmp(argv[1], "INIT") == 0) {
			CommandInit(argv);
			return TCL_OK;
		} else if (strcmp(command, "PRINT") == 0) {
			const char* commandPrint = argv[2];
			CommandPrint(commandPrint);
			return TCL_OK;
		} else if (strcasecmp (argv[1], "tracetarget") == 0) {
			TclObject *obj;
			if ((obj = TclObject::lookup (argv[2])) == 0) {
				fprintf (stderr, "%s: %s lookup of %s failed\n", 
								__FILE__, argv[1], argv[2]);
				return TCL_ERROR;
			}
			tracetarget = (Trace *) obj;
			return TCL_OK;
		} else if (strcasecmp(argv[1], "port-dmux") == 0) {
			return TCL_OK;
		} else if (strcasecmp(argv[1], "node") == 0) {
			node = (MobileNode*) TclObject::lookup(argv[2]);
			return TCL_OK;
		} else if (strcasecmp(argv[1], "addr") == 0) {
			myaddr = Address::instance().str2addr(argv[2]);
			compSensor->setSensorId(myaddr);
			compSensor->setAgent(this);
			compCH->setAgent(this);
			compCM->setAgent(this);
			return TCL_OK;
		} else if(strcasecmp(argv[1],"POSITION")==0) {
			if(compSensor->getSensorId() == 0) return TCL_OK;
		 	CommandPosition(argv);

			return TCL_OK;
		}
	}
	return (Agent::command(argc, argv));
}

void WSN_ComponentsAgent::CommandPrint(const char* p) { 
	if (strcmp(p, "GET_NEIGHBORS") == 0) 
		compSensor->getNeighbors();
	else if (strcmp(p, "CANDIDATECH") == 0)
		compSensor->CommandPrintCandidateCH();
	else if (strcmp(p, "MEMBERS") == 0)
		compSensor->CommandPrintCandidateMembers();
	else if (strcmp(p, "CHs") == 0)
		compSensor->CommandPrintCHs();
	else if (strcmp(p, "TWOHOP_CH") == 0)
		compSensor->CommandPrintTwoHopCandidateCH();
	else if (strcmp(p, "TWO_HOP_NEIGHBORS") == 0) {
		printf("\nVizinhos 2 hop de %d (%f): ", compSensor->getSensorId(), CURRENT_TIME);
		for (list<int>::iterator i = lstTwoHopNeighbors.begin(); i != lstTwoHopNeighbors.end(); i++) {
			printf("%d",(*i));
		}
	}
	else if (strcasecmp (p, "WINNERS") == 0)
		compSensor->CommandPrintWinners();
	else if (strcasecmp (p, "MIN_WINNERS") == 0)
		compSensor->CommandPrintMINWinners();
}

void WSN_ComponentsAgent::CommandInit(const char*const* argv) { 
	int numSensors = atoi(argv[2]); // $val(num_sensors)
	int dHops = atoi(argv[3]); // $val(d_hops)
	compSensor->init(numSensors, dHops);
	compCH->setHops(dHops);
	compCH->setMinHops(dHops);
	compSensor->setWinner(compSensor->getSensorId());
}

void WSN_ComponentsAgent::CommandPosition(const char*const* argv) {
	compSensor->setCoords(atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
}

void WSN_ComponentsAgent::SendPkt(MsgID msgID, WSN_Components_Message* param) {
	param->setPrevHop(compSensor->getSensorId());
	param->setNextHop(IP_BROADCAST);
	param->setAddressType(NS_AF_INET);
	param->setDirection(hdr_cmn::DOWN);

	double r = ((double) rand() / (RAND_MAX));
	Scheduler::instance().schedule(target_, param->getPkt(), (r/10));
}

void WSN_ComponentsAgent::recv(Packet* pkt, Handler *) {
	assert(initialized());
	assert(pkt);

	WSN_Components_Message param = pkt;
	compSensor->ProcessMessage(&param);
}

void WSN_ComponentsAgent::CommandDiscoverNeighbors() {
	double r = ((double) rand() / (RAND_MAX));
	compSensor->setSensorId(myaddr);
	roundCmd = DISCOVER_NEIGHBORS;
	libTimer.initTimer(CURRENT_TIME + (r / 10));
}

void WSN_ComponentsAgent::CommandFloodMax() {
	double r = ((double) rand() / (RAND_MAX));
	compSensor->setSensorId(myaddr);
	libTimer.initTimer(CURRENT_TIME + (r / 10));
	roundCmd = FLOODMAX;
}

void WSN_ComponentsAgent::TimerHandle(RoundCommand cmd) {
	double r = ((double) rand() / (RAND_MAX));

	switch (cmd) {
		case DISCOVER_NEIGHBORS:
		{
			compSensor->ManageRoundCommand(roundCmd);
			libTimer.resetTimer(CURRENT_TIME + (r / 10));
		}
		break;
		case ACK_DISCOVER_NEIGHBORS:
		{
			compSensor->ManageRoundCommand(roundCmd);
			roundCmd = FINISH;
		}
		break;
		case CALCULATE_MAX:
		{
			int winner = compSensor->CalculateMAX();
			roundCmd = FLOODMAX;
			libTimer.resetTimer(CURRENT_TIME + (r / 10));
		}
		break;
		case FLOODMAX:
		{
			printf("FLOOD_MAX %f\n", CURRENT_TIME);
			if (compCH->getHops() > 0) {
				compSensor->ManageRoundCommand(roundCmd);
				compCH->setHops(compCH->getHops()-1);
				this->roundCmd = CALCULATE_MAX;
			}
			else {
				this->roundCmd = FLOODMIN;
				printf("FLOOD_MAX %f\n", CURRENT_TIME);
				compSensor->ResetFloodMAXMIN();
			}
			libTimer.resetTimer(CURRENT_TIME + (r / 10));
		}
		break;
		case CALCULATE_MIN:
		{
			int winner = compSensor->CalculateMIN();
			roundCmd = FLOODMIN;
			libTimer.resetTimer(CURRENT_TIME + (r / 10));
		}
		break;
		case FLOODMIN:
		{
			if (compCH->getMinHops() > 0) {
				compSensor->ManageRoundCommand(roundCmd);
				compCH->setMinHops(compCH->getMinHops()-1);
				this->roundCmd = CALCULATE_MIN;
			}
			else {
				printf("TimerHandle FLOOD_MIN %f\n", CURRENT_TIME);
				roundCmd = SELECT_CH;
			}
			libTimer.resetTimer(CURRENT_TIME + (r / 10));
		}
		break;
		case SELECT_CH:
		{
			printf("TimerHandle SELECT_CH %f\n", CURRENT_TIME);
			map<string, int> mapUID = compSensor->GetCHElectionParams();
			compCH->SelectCH(mapUID);
			roundCmd = JOIN_CLUSTER;
			libTimer.resetTimer(CURRENT_TIME + (r/10));
		}
		break;
		case JOIN_CLUSTER:
		{
			compSensor->resetfloodingsent();
			map<string, map<string, int> > mapCandidateCH = compSensor->GetJoinParams();
			if (mapCandidateCH.size() > 0) {
				compCM->JoinCluster(mapCandidateCH);
			}
		}
			break;
	}
}

template <class T>
void WSN_Timer::initTimer(T t) {
	Scheduler::instance().schedule(this, &intr, t);
}

template <class T>
void WSN_Timer::resetTimer(T t) {
	Scheduler::instance().schedule(this, &intr, t);
}

void WSN_Timer::handle(Event* /*e*/) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(a_);

	if (agent->roundCmd == DISCOVER_NEIGHBORS) {
		agent->TimerHandle(DISCOVER_NEIGHBORS);
		agent->roundCmd = ACK_DISCOVER_NEIGHBORS;
	} else if (agent->roundCmd == ACK_DISCOVER_NEIGHBORS) {
		agent->TimerHandle(ACK_DISCOVER_NEIGHBORS);
	} else if (agent->roundCmd == FLOODMAX) {
		agent->TimerHandle(FLOODMAX);
	} else if (agent->roundCmd == CALCULATE_MAX) {
		agent->TimerHandle(CALCULATE_MAX);
	} else if (agent->roundCmd == CALCULATE_MIN) {
		agent->TimerHandle(CALCULATE_MIN);
	} else if (agent->roundCmd == FLOODMIN) {
		agent->TimerHandle(FLOODMIN);
	} else if (agent->roundCmd == SELECT_CH) {
		agent->TimerHandle(SELECT_CH);
		agent->roundCmd = JOIN_CLUSTER;
	} else if (agent->roundCmd == JOIN_CLUSTER) {
		agent->TimerHandle(JOIN_CLUSTER);
		agent->roundCmd = FINISH;
	}
}

template void WSN_Timer::initTimer(double);
template void WSN_Timer::resetTimer(double);
