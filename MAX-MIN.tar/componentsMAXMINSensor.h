#ifndef _WSN_COMPONENTS_MAXMIN_SENSOR_
#define _WSN_COMPONENTS_MAXMIN_SENSOR_

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <sstream>
#include "packet.h"
#include "hdr_components.h"
#include <mobilenode.h>
#include "agent.h"
#include "componentsLib.h"

using namespace std;

class WSN_ComponentsSensor;

enum SensorRole {
	UNKNOWN,
	CH,
	CM
};

class WSN_ComponentsSensor {

public: 
	WSN_ComponentsSensor();
	void setAgent(Agent *);
	void setSensorId(int);
	void setWinner(int);
	std::map<string, int> GetCHElectionParams();
	std::map<string, map<string, int> > GetJoinParams();

	void init(int, int);

	SensorRole role;

	int CalculateMAX();
	int CalculateMIN();
	void AddNeighbor(SensorDataParams);
	void getNeighbors();
	void AddProbe(SensorDataParams);
	void ProcessMessage(WSN_Components_Message *);
	void ManageRoundCommand(RoundCommand);
	void AddCandidateCH(SensorDataParams);
	void AddCandidateMember(SensorDataParams);
	void AddFloodMAXMIN(SensorDataParams);
	void ResetFloodMAXMIN();
	void CommandPrintCandidateCH();
	void CommandPrintCHs();
	void CommandPrintWinners();
	void CommandPrintMINWinners();
	void CommandPrintTwoHopCandidateCH();
	void CommandPrintCandidateMembers();
	void resendstartflooding(WSN_Components_Message*);

	bool contains(int addr, vector<int> v){
		for(vector<int>::iterator i = v.begin(); i != v.end(); i++){
			if((*i) == addr) {
				return true;
			}
		}
		return false;
	}

	bool contains(int addr, vector<SensorDataParams> v){
		for(vector<SensorDataParams>::iterator i = v.begin(); i != v.end(); i++){
			if((*i).id == addr) {
				return true;
			}
		}
		return false;
	}

	bool isfloodingsent(int uid){
		for (list<int>::iterator i = lstpktflooding.begin(); i != lstpktflooding.end(); i++){
			if ((*i) == uid){
				return true;
			}
		}
		return false;
	}

	void resetfloodingsent() { lstpktflooding.clear(); }

	void addfloodingsent(int uid){
		lstpktflooding.push_front(uid);
	}

	vector<SensorDataParams> getVecFloodMAXMIN() { return vecFloodMAXMIN; }
	vector<SensorDataParams> getVecCandidateCH() { return vecCandidateCH; }
	vector<int> getVecTwoHopCandidateCH() { return vecTwoHopCandidateCH; }
	vector<SensorDataParams> getVecCandidateMembers() { return vecCandidateMembers; }
	vector<SensorDataParams> getVecRecvProbeMsg() { return vecRecvProbeMsg; }
	vector<SensorDataParams> getVecNeighbors() { return vecNeighbors; }

	list<int> lstpktflooding;

	int getSensorId() {
		return sensorId;
	}

	// sensor coordinators
	int getX()  { return coordX; }
	int getY() { return coordY; }
	int getZ()  { return coordZ; }
	void setX(int latitude)  { coordX = latitude; }
	void setY(int longitude) { coordY = longitude; }
	void setZ(int altitude)  { coordZ = altitude; }
	void setCoords(int lat, int lon, int alt) {
		coordX = lat;
		coordY = lon;
		coordZ = alt;
	}

	int getNumSensors() { return numSensors; }

private:
	Agent *agent_;
	WSN_ComponentsLib *compLib;
	int sensorId;
	int dHops;
	int winner;
	int winnerMIN;

	// Neighbors
	vector<SensorDataParams> vecNeighbors;
	map<string, int> mapNeighbors;
	map<string, int> mapFloodMAXMIN;

	vector<SensorDataParams> vecFloodMAXMIN;
	vector<int> vecCHNeighbors;

	//CandidateCH
	vector<SensorDataParams> vecCandidateCH;
	vector<int> vecTwoHopCandidateCH;
	vector<SensorDataParams> vecCandidateMembers;
	vector<int> vecFloodMax;
	vector<int> vecFloodMin;
	vector<SensorDataParams> vecRecvProbeMsg;

	int coordX;
	int coordY;
	int coordZ;

	int numSensors;
};

#endif
