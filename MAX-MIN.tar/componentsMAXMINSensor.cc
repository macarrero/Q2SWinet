#include "componentsMAXMINSensor.h"
#include "componentsMAXMIN.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsSensor::WSN_ComponentsSensor() {
	compLib = new WSN_ComponentsLib();
}

void WSN_ComponentsSensor::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsSensor::setSensorId(int id) {
	sensorId = id;
}

void WSN_ComponentsSensor::setWinner(int id) {
	winner = id;
}

std::map<string, int> WSN_ComponentsSensor::GetCHElectionParams() {
	std::map<string, int> mapMin;
	std::string strId=("ID");

	for (vector<int>::iterator i = vecFloodMin.begin(); i != vecFloodMin.end(); i++) {
		string newId = static_cast<std::ostringstream*>( &(ostringstream() << *i) )->str();
		mapMin.insert(std::pair<string, int> (strId.append(newId), *i));
	}

	return mapMin;
}

std::map<string, map<string, int> > WSN_ComponentsSensor::GetJoinParams() {
	std::map<string, int> mapMax;
	std::map<string, int> mapMin;
	std::map<string, map<string, int> > mapCHParams;
	std::string strId=("ID");

	for (vector<int>::iterator i = vecFloodMin.begin(); i != vecFloodMin.end(); i++) {
		string newId = static_cast<std::ostringstream*>( &(ostringstream() << *i) )->str();
		mapMin.insert(std::pair<string, int> (strId.append(newId), *i));
	}

	mapCHParams.insert(std::pair<string, map<string, int> > ("MIN", mapMin) );

	for (vector<int>::iterator j = vecFloodMax.begin(); j != vecFloodMax.end(); j++) {
		string newId = static_cast<std::ostringstream*>( &(ostringstream() << *j) )->str();
		mapMax.insert(std::pair<string, int> (strId.append(newId), *j));
	} 

	mapCHParams.insert(std::pair<string, map<string, int> > ("MAX", mapMax) );

	return mapCHParams;
}

void WSN_ComponentsSensor::init(int numSensors, int dHops) {
	this->numSensors = numSensors;
	this->dHops = dHops;
}

void WSN_ComponentsSensor::AddProbe(SensorDataParams sensorDataParams) {
	vecRecvProbeMsg.push_back(sensorDataParams);
}

void WSN_ComponentsSensor::AddNeighbor(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecNeighbors)) {
		vecNeighbors.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::AddCandidateCH(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecCandidateCH)) {
		vecCandidateCH.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::AddCandidateMember(SensorDataParams sensorDataParams) {
	if (!contains(sensorDataParams.id, vecCandidateMembers)) {
		vecCandidateMembers.push_back(sensorDataParams);
	}
}

void WSN_ComponentsSensor::ManageRoundCommand(RoundCommand roundCmd) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);
	param.setId(getSensorId());

	switch (roundCmd) {
		case DISCOVER_NEIGHBORS:
		{
			param.setMsgId(SENSOR_ID);

			newp.size = 1;
			sp.id = param.getId(); 
			sp.coordX = getX();
			sp.coordY = getY();
			sp.coordZ = getZ();

			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			agent->SendPkt(SENSOR_ID, &param);
		}
		break;
		case ACK_DISCOVER_NEIGHBORS:
		{
			param.setMsgId(ACK_SENSOR_ID);
			newp.size = getVecRecvProbeMsg().size();

			int i = 0;

			for (vector<SensorDataParams>::iterator x=vecRecvProbeMsg.begin(); x!= vecRecvProbeMsg.end(); x++) {
				printf("No %d envia ACK_SENSOR_ID para %d (%f) \n", getSensorId(), (*x).id, CURRENT_TIME);
				sp.id = (*x).id;
				sp.coordX = (*x).coordX;
				sp.coordY = (*x).coordY;
				sp.coordZ = (*x).coordZ;

				newp.msgParam[i] = sp;
				i++;
			}
			param.getHdrWsnComp()->msgParams = newp;
			agent->SendPkt(ACK_SENSOR_ID, &param); 
		}
		break;
		case FLOODMAX:
		case FLOODMIN:
		{
			param.setMsgId(WINNER);
			newp.size = 1;
			sp.id = winner; 
			sp.coordX = getX();
			sp.coordY = getY();
			sp.coordZ = getZ();

			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;
			agent->SendPkt(WINNER, &param);
		}
		break;
	}
}

void WSN_ComponentsSensor::ProcessMessage(WSN_Components_Message* param) {
	double Xr, Yr, Zr;
	param->getPkt()->txinfo_.getNode()->getLoc(&Xr, &Yr, &Zr);
	SensorDataParams sp;

	switch(param->getMsgId())
	{
		case (SENSOR_ID):
		{
			int id = param->getHdrWsnComp()->msgParams.msgParam[0].id;

			sp.id = param->getHdrWsnComp()->msgParams.msgParam[0].id;
			sp.coordX = param->getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			sp.coordY = param->getHdrWsnComp()->msgParams.msgParam[0].coordY; 

			AddProbe(sp); 
		}
		break;
		case (ACK_SENSOR_ID):
		{
			printf("No %d rcv ACK_SENSOR_ID (%f) \n", getSensorId(), CURRENT_TIME);
			int size = param->getHdrWsnComp()->msgParams.size;
			for (int i=0; i < size; i++) {
				if (getSensorId() == param->getHdrWsnComp()->msgParams.msgParam[i].id) { 
					sp.id = param->getHdrCmn()->prev_hop_; 
					sp.coordX = Xr; 
					sp.coordY = Yr;

					AddNeighbor(sp);
				}
			}
		}
		break;
		case (WINNER):
		case (WINNER_MIN):
		{
			sp.id = param->getHdrWsnComp()->msgParams.msgParam[0].id; 
			sp.coordX = param->getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			sp.coordY = param->getHdrWsnComp()->msgParams.msgParam[0].coordY; 

			AddFloodMAXMIN(sp);

		}
		break;
		case (CH_ANNOUNCE):
		{
			sp.id = param->getHdrWsnComp()->msgParams.msgParam[0].id; 
			sp.coordX = param->getHdrWsnComp()->msgParams.msgParam[0].coordX; 
			sp.coordY = param->getHdrWsnComp()->msgParams.msgParam[0].coordY;

			//if (role != CH) {
				AddCandidateCH(sp);

				if (isfloodingsent(1)) {
					Packet::free( param->getPkt());
					break;
				}

				addfloodingsent(1);
				resendstartflooding(param);

		}
		break;
		case (ACK_CH_ANNOUNCE):
		{
			int size = param->getHdrWsnComp()->msgParams.size;
				for (int i=0; i < size; i++) {
					if (getSensorId() == param->getHdrWsnComp()->msgParams.msgParam[i].id) {
						sp.id = param->getHdrCmn()->prev_hop_;
						AddCandidateMember(sp);
					}
				}
				if (isfloodingsent(1)) {
					Packet::free( param->getPkt());
					break;
				}

				addfloodingsent(1);
				resendstartflooding(param);
		}
		break;
	}
}

void WSN_ComponentsSensor::resendstartflooding(WSN_Components_Message* param){
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;

	param->setId(1);
	param->getHdrCmn()->uid_ = 1;
	param->setNextHop(IP_BROADCAST);
	param->setAddressType(NS_AF_INET);
	param->setDirection(hdr_cmn::DOWN);		// packet direction
	param->setPrevHop(getSensorId());

	sp.id = param->getId();
	newp.size = 1;
	newp.msgParam[0] = sp;

	agent->SendPkt(param->getMsgId(), param);
	addfloodingsent(1);
}

void WSN_ComponentsSensor::ResetFloodMAXMIN() {
	mapFloodMAXMIN.clear();
}

void WSN_ComponentsSensor::AddFloodMAXMIN(SensorDataParams sensorDataParams) {
	std::string strId=("ID");
	int id = sensorDataParams.id;
	string newId = static_cast<std::ostringstream*>( &(ostringstream() << id) )->str();
	mapFloodMAXMIN.insert(std::pair<string, int> (strId.append(newId), id));
}

int WSN_ComponentsSensor::CalculateMAX() {
	int maxId;
	if ( mapFloodMAXMIN.size() > 0 ) {
		maxId = compLib->MAX(mapFloodMAXMIN).at("ID");
		if ( maxId > winner ) {
			winner = maxId;
			vecFloodMax.push_back(maxId);
		}
		else
			vecFloodMax.push_back(winner);
	}
}

int WSN_ComponentsSensor::CalculateMIN() {
	int minId;
	if ( mapFloodMAXMIN.size() > 0 ) {
		minId = compLib->MIN(mapFloodMAXMIN).at("ID");
		if ( minId < winner ) {
			winner = minId;
			vecFloodMin.push_back(minId);
		}
		else
			vecFloodMin.push_back(winner);
	}
}

void WSN_ComponentsSensor::getNeighbors() {
	printf("\nVecNeig de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecNeighbors.begin(); i != vecNeighbors.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintCHs() {
	if (this->role == CH)
		printf("\nCH %d (%f): ", getSensorId(), CURRENT_TIME);
}

void WSN_ComponentsSensor::CommandPrintCandidateCH() {
	printf("\nCandidateCH %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecCandidateCH.begin(); i != vecCandidateCH.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintCandidateMembers() {
	printf("\nCandidateMembers de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<SensorDataParams>::iterator i = vecCandidateMembers.begin(); i != vecCandidateMembers.end(); i++) {
		printf("%d ",(*i).id);
	}
}

void WSN_ComponentsSensor::CommandPrintWinners() {
	printf("\nPrintWinners de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<int>::iterator i = vecFloodMax.begin(); i != vecFloodMax.end(); i++) {
		printf("%d ",(*i));
	}
}

void WSN_ComponentsSensor::CommandPrintMINWinners() {
	printf("\nPrintMINWinners de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<int>::iterator i = vecFloodMin.begin(); i != vecFloodMin.end(); i++) {
		printf("%d ",(*i));
	}
}

void WSN_ComponentsSensor::CommandPrintTwoHopCandidateCH() {
	printf("\nTwoHopCH de %d (%f): ", getSensorId(), CURRENT_TIME);
	for (vector<int>::iterator i = vecTwoHopCandidateCH.begin(); i != vecTwoHopCandidateCH.end(); i++) {
		printf("%d ",(*i));
	}
}
