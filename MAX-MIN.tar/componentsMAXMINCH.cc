#include <string>
#include "componentsMAXMINCH.h"
#include "componentsMAXMIN.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsCH::WSN_ComponentsCH() {}

WSN_ComponentsCH::WSN_ComponentsCH(Agent *agent) {
	compLib = new WSN_ComponentsLib();
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCH::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCH::setWinner(int id) {
	winner = id;
}

void WSN_ComponentsCH::setHops(int dHops) {
	this->dHops = dHops;
}

void WSN_ComponentsCH::setMinHops(int dHops) {
	this->dMinHops = dHops;
}

int WSN_ComponentsCH::getHops() {
	return this->dHops;
}

int WSN_ComponentsCH::getMinHops() {
	return this->dMinHops;
}

template <class K, class V> void WSN_ComponentsCH::SelectCH(std::map<K, V> setNeighbors) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	SensorDataParams sp;
	MsgParam newp;
	Packet* pkt = agent->getNewPkt();
	WSN_Components_Message param(pkt);

	// Rule 1: First, each node checks to see if it has received its own original node id in the 2nd rounds of flooding. If it has own 			original node id in the 2nd d rounds 	then it can declare itself a clusterhead and skip the rest of this phase of the heuristic.
	for (map<string, int>::iterator it = setNeighbors.begin(); it != setNeighbors.end(); it++) {
		if (it->second == agent->getCompSensor()->getSensorId()) {
			printf("SELECT_CH no %d Sou CH %f\n", agent->getCompSensor()->getSensorId(), CURRENT_TIME);

			param.setId(agent->getCompSensor()->getSensorId());
			param.setMsgId(CH_ANNOUNCE);
			sp.id = param.getId();

			newp.size = 1;
			newp.msgParam[0] = sp;

			param.getHdrWsnComp()->msgParams = newp;

			agent->getCompSensor()->role = CH;
			agent->SendPkt(CH_ANNOUNCE, &param);

			break;
		}
	}
}

template void WSN_ComponentsCH::SelectCH(std::map<string, int>);
