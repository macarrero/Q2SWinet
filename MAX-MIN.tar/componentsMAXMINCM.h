#ifndef _WSN_COMPONENTS_MAXMIN_CM_
#define _WSN_COMPONENTS_MAXMIN_CM_

#include <mobilenode.h>
#include "address.h"
#include "tclcl.h"
#include "ip.h"
#include <map>

class WSN_ComponentsCM;

class WSN_ComponentsCM {
public:
	WSN_ComponentsCM();	
	WSN_ComponentsCM(Agent *);
	template <typename K, typename V> void JoinCluster(std::map<K, V>);
	void setAgent(Agent *);

private:
	WSN_ComponentsLib *compLib;

protected:
	Agent *agent_;
	Packet *pkt;
	MobileNode *node;
	Trace *tracetarget;
};

#endif
