#ifndef _WSN_COMPONENTS_LIB_
#define _WSN_COMPONENTS_LIB_

#include <map>
#include "timer-handler.h"
#include "agent.h"

using namespace std;

class WSN_ComponentsLib;

class WSN_Timer : public Handler {
public:
	WSN_Timer(WSN_ComponentsLib *est) : Handler() { est_ = est; }
	WSN_Timer(Agent *a) : Handler() { a_ = a; }
	
public:
	//void expire(Event *e);
	void handle(Event *e);
	template <class T> void initTimer(T);
	template <class T> void resetTimer(T);
	WSN_ComponentsLib *est_;
	Agent *a_;
	Event intr;
};

class WSN_ComponentsLib {

friend class WSN_Timer;

public:
	WSN_ComponentsLib();
	template <typename K, typename V> map<K, V> MIN(map<K, V>);
	template <typename K, typename V> map<K, V> MAX(map<K, V>);
	template <typename K, typename V> V AVG(map<K, V>);
	template <typename K, typename V> V SUM(map<K, V>);

protected:
	WSN_Timer lib_timer_;

};

#endif
