#include <string>
#include "componentsMAXMIN.h"
#include "componentsMAXMINCM.h"

using namespace std;

#define CURRENT_TIME    Scheduler::instance().clock()

WSN_ComponentsCM::WSN_ComponentsCM() {}

WSN_ComponentsCM::WSN_ComponentsCM(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
}

void WSN_ComponentsCM::setAgent(Agent *agent) {
	this->agent_ = dynamic_cast<WSN_ComponentsAgent*>(agent);
	compLib = new WSN_ComponentsLib();
}

template <class K, class V> void WSN_ComponentsCM::JoinCluster(std::map<K, V> setCandidateCH) {
	WSN_ComponentsAgent* agent = dynamic_cast<WSN_ComponentsAgent*>(agent_);
	if ( agent->getCompSensor()->role != CH ) {
		Packet* pkt = agent->getNewPkt();
		WSN_Components_Message param(pkt);
		MsgParam newp;
		SensorDataParams sp;

		// Rule 2: Each node looks for node pairs. Once a node has identified all node pairs, it selects the minimum node pair to be the 			clusterhead. If a node pair does not exist for a node then proceed to Rule 3.
		std::string strId=("ID");
		map<string, int> mapNodePairs;
		map<string, int> mapMax = setCandidateCH["MAX"];
		map<string, int> mapMin = setCandidateCH["MIN"];
		for (map<string, int>::iterator i = mapMin.begin(); i != mapMin.end(); i++) {
			for (map<string, int>::iterator j = mapMax.begin(); j != mapMax.end(); j++) {
				if ( j->second == i->second ) {
					string newId = static_cast<std::ostringstream*>( &(ostringstream() << j->second) )->str();
					mapNodePairs.insert(std::pair<string, int> (strId.append(newId), j->second));
					break;
				}
			}
		}

		if (mapNodePairs.size() >0) {
			sp.id = compLib->MIN(mapNodePairs).at("ID");
		} else { // Rule 3: Elect the maximum node id in the 1st rounds of flooding as the clusterhead for this node.
			sp.id = compLib->MAX(mapMax).at("ID");
		}
		
		param.setId(agent->getCompSensor()->getSensorId());
		newp.size = 1;
		newp.msgParam[0] = sp;
		param.setMsgId(ACK_CH_ANNOUNCE);
		param.getHdrWsnComp()->msgParams = newp;
		agent->SendPkt(ACK_CH_ANNOUNCE, &param);
	}
}

template void WSN_ComponentsCM::JoinCluster(std::map<string, map<string, int> >);
