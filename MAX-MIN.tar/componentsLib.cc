#include "componentsLib.h"
#include <string>
#include <cstdlib>
#include <stdio.h>

WSN_ComponentsLib::WSN_ComponentsLib() : lib_timer_(this) {
}

template <typename K, typename V> map<K, V> WSN_ComponentsLib::MIN(map<K, V> G) {
	map<string, int>::iterator itNeighbors = G.begin();

	map<string, int> retMinUID;

	int minID = itNeighbors->second;
	while ( itNeighbors != G.end() ) {
		if (itNeighbors->second < minID) 
			minID = itNeighbors->second;

		++itNeighbors;
	}

	retMinUID.insert(pair<string, int> ("ID", minID));

	return retMinUID;
}

template <typename K, typename V> map<K, V> WSN_ComponentsLib::MAX(map<K, V> G) {
	//printf("maxID \n");
	map<string, int>::iterator itNeighbors = G.begin();

	map<string, int> retMaxUID;
	
	int maxID = itNeighbors->second;
	while ( itNeighbors != G.end() ) {
		if (itNeighbors->second > maxID)
			maxID = itNeighbors->second;

		++itNeighbors;
	}

	retMaxUID.insert(pair<string, int> ("ID", maxID));

	return retMaxUID;
}

template map<string, int> WSN_ComponentsLib::MIN(map<string, int>);
template map<string, int> WSN_ComponentsLib::MAX(map<string, int>);
