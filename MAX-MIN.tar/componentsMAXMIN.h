#ifndef _WSN_COMPONENTS_MAXMIN_
#define _WSN_COMPONENTS_MAXMIN_

#include <mobilenode.h>
#include "componentsMAXMINCH.h"
#include "componentsMAXMINCM.h"
#include "componentsMAXMINSensor.h"
#include "componentsLib.h"
#include "agent.h"
#include "packet.h"
#include "address.h"
#include "tclcl.h"
#include "ip.h"

using namespace std;

class WSN_ComponentsAgent;

typedef struct{
	int pktid;
} pktflooding;


class WSN_ComponentsAgent: public Agent {
	friend class  WSN_Timer;

	int numSensors_;
	
public:
	WSN_ComponentsAgent();
	SensorRole role;
	int** neighboringMatrix;
	void createneighboringMatrix(int, int);
	void SendPkt(MsgID, WSN_Components_Message *);
	void AddFloodingSent(int);
	void AddTwoHopNeighbor(int);
	bool IsFloodingSent(int);
	void CommandInit(const char*const* argv);
	void CommandPosition(const char*const* argv);
	void CommandDiscoverNeighbors();
	void CommandFloodMax();
	void CommandGetNeighbors();
	void CommandPrint(const char*);
	void CommandPing();
	void TimerHandle(RoundCommand);
	inline Packet* getNewPkt() { return allocpkt(); }
	virtual void recv (Packet *, Handler *);
	virtual int command(int, const char*const*);
	RoundCommand roundCmd;

	WSN_ComponentsSensor* getCompSensor() { return compSensor; }
	WSN_Timer getLibTimer() { return libTimer; }

protected:
	MobileNode *node;
	Trace *tracetarget;
	int myaddr;
	MsgID lastMsg;
	list<pktflooding> lstPktFlooding;

	// Neighbors
	vector<int> vecNeighbors;
	list<int> lstTwoHopNeighbors;

	WSN_Timer libTimer;

private:

	WSN_ComponentsSensor* compSensor;
	WSN_ComponentsCH *compCH;
	WSN_ComponentsCM *compCM;
	WSN_ComponentsLib compLib;

	vector<SensorDataParams> vecSensorDataParams;

};

#endif
